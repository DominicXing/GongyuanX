#include<iostream>
#include<string>
#include "MovieTree.h"

std::ostream& operator<<(std::ostream& os, MovieNode* n)
{
  os << "Movie: " << n->title << std::endl;
  return os;
}

MovieNode::MovieNode()
{
  parent = nullptr;
  title = "";
  year = -1;
  quantity = -1;
  ranking = -1;
  left = nullptr;
  right = nullptr;
}

MovieNode::MovieNode(int& rating, std::string& ttl, int& yr, int& qtty)
{
  parent = nullptr;
  title = ttl;
  year = yr;
  quantity = qtty;
  ranking = rating;
  left = nullptr;
  right = nullptr;
}

MovieNode::~MovieNode()
{

}

MovieTree::MovieTree()
{
  root = nullptr;
}


MovieTree::~MovieTree()
{
  void delete_tree(MovieNode*);
}


void MovieTree::addRawNode(int& rank, std::string& ttl, int& yr, int& qtty)
{
  MovieNode* n = new MovieNode(rank, ttl, yr, qtty); 
  insert(n); 


MovieNode* MovieTree::search(std::string& ttl)
{
  MovieNode* n = root; 
  if (n == nullptr || n->title == ttl) 
    return n;
  if (ttl.compare(n->title) < 0)     
    return search(n->left, ttl);
  else
    return search(n->right, ttl);
}


MovieNode* MovieTree::search(MovieNode* n, std::string& ttl)
{
  if (n == nullptr || n->title == ttl)
    return n;
  if (ttl.compare(n->title) < 0)
    return search(n->left, ttl);
  else
    return search(n->right, ttl);
}

MovieNode* MovieTree::iterative_search(std::string& ttl)
{
  MovieNode* n = root;
  while (n != nullptr && ttl != n->title) 
  {
    if (ttl.compare(n->title) < 0)
      n = n->left;
    else
      n = n->right;
  }
  return n;
}


void MovieTree::inorder_walk()
{
  MovieNode* n = root;  
  if (n != nullptr || NULL) 
  {
    inorder_walk(n->left); 
    std::cout << n;    
    inorder_walk(n->right); 
  }
}


void MovieTree::inorder_walk(MovieNode* n)
{
  if (n != nullptr || NULL)
  {
    inorder_walk(n->left);
    std::cout << n;
    inorder_walk(n->right);
  }
}


MovieNode* MovieTree::minimum()
{
  MovieNode* n = root;
  while (n->left != nullptr || NULL)  
    n = n->left;          
  return n;
}


MovieNode* MovieTree::minimum(MovieNode* n)
{
  while (n->left != nullptr || NULL)
    n = n->left;
  return n;
}


MovieNode* MovieTree::maximum() 
{
  MovieNode* n = root;   
  while (n->right != nullptr)
    n = n->right;
  return n;
}


MovieNode* MovieTree::maximum(MovieNode* n)
{
  while (n->right != nullptr || NULL)
    n = n->right;
  return n;
}

MovieNode* MovieTree::successor(MovieNode* n)
{
  if (n->right != nullptr || NULL)
    return minimum(n);     
  MovieNode* trail = n->parent; 
  while (trail != nullptr && n == trail->right) 
  {
    n = trail;
    trail = trail->parent;  
  }
  return trail;
}

/ find next smallest in tree
MovieNode* MovieTree::predecessor(MovieNode* n)
{
  if (n->left != nullptr || NULL)
    return maximum(n);     
  MovieNode* trail = n->parent;
  while (trail != nullptr && n == trail->left)    
  {
    n = trail;
    trail = trail->parent;  
  }
  return trail;
}


void MovieTree::insert(MovieNode* new_node)
{
  MovieNode* n = root; 
  MovieNode* trail = nullptr;
  while (n != nullptr)  
  {
    trail = n;     
    if (new_node->title.compare(n->title) < 0)
      n = n->left;  
    else
      n = n->right; 
  }
  new_node->parent = trail;
  if (trail == nullptr) 
    root = new_node;
  else if (new_node->title.compare(trail->title) < 0)
    trail->left = new_node;  
  else
    trail->right = new_node;  
}


void MovieTree::insert(MovieNode* start, MovieNode* new_node)
{
  MovieNode* n = start;
  MovieNode* trail = nullptr;
  while (n != nullptr) 
  {
    trail = n;     
    if (new_node->title.compare(n->title) < 0)
      n = n->left; 
    else
      n = n->right;
  }
  new_node->parent = trail;
  if (trail == nullptr)
    root = new_node;
  else if (new_node->title.compare(trail->title) < 0)
    trail->left = new_node;
  else
    trail->right = new_node;
}


void MovieTree::transplant(MovieNode* u, MovieNode* v)  
  if (u->parent == nullptr) 
    root = v;
  else if (u == u->parent->left)  
    u->parent->left = v;   
  else
    u->parent->right = v;   

  if (v != nullptr)      
    v->parent = u->parent;
}


void MovieTree::delete_node(MovieNode* del_node)  
{
  if (del_node->left == nullptr)         
    transplant(del_node, del_node->right);    
  else if (del_node->right == nullptr)     
    transplant(del_node, del_node->left);   
  else
  {
    MovieNode* temp = minimum(del_node->right); 
    if (temp->parent != del_node)      
    {
      transplant(temp, temp->right);     
      temp->right = del_node->right;      
      temp->parent->right = temp;       
    }
    transplant(del_node, temp);         
    temp->left = del_node->left;      
    temp->left->parent = temp;          
}


void MovieTree::delete_tree(MovieNode* rt)
{
  if (rt->left != NULL || rt->left != nullptr)   
    delete_tree(rt->left);
  if (rt->right != NULL || rt->right != nullptr)
    delete_tree(rt->right);
  delete rt;
}
